package com.banking.service;

public class KycService {
}
