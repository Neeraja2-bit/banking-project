package com.banking.Enum;

public enum AccountType {
    SAVINGS,
    CURRENT
}
